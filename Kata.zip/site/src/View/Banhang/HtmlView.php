<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_banhangs
 *
 * @copyright   (C) 2006 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Joomla\Component\Banhangs\Site\View\Banhang;

\defined('_JEXEC') or die;

use Joomla\CMS\Categories\Categories;
use Joomla\CMS\Factory;
use Joomla\CMS\Feed\FeedFactory;
use Joomla\CMS\Helper\TagsHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\GenericDataException;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\Component\Banhangs\Site\Helper\RouteHelper;

/**
 * HTML View class for the Banhangs component
 *
 * @since  1.0
 */
class HtmlView extends BaseHtmlView
{
	/**
	 * The model state
	 *
	 * @var     object
	 * @since   1.6
	 */
	protected $state;

	/**
	 * The banhang item
	 *
	 * @var     object
	 * @since   1.6
	 */
	protected $item;

	/**
	 * UNUSED?
	 *
	 * @var     boolean
	 * @since   1.6
	 */
	protected $print;

	/**
	 * The current user instance
	 *
	 * @var    \JUser|null
	 * @since  4.0.0
	 */
	protected $user = null;

	/**
	 * The page class suffix
	 *
	 * @var    string
	 * @since  4.0.0
	 */
	protected $pageclass_sfx = '';

	/**
	 * The page parameters
	 *
	 * @var    \Joomla\Registry\Registry|null
	 * @since  4.0.0
	 */
	protected $params;

	/**
	 * Execute and display a template script.
	 *
	 * @param   string  $tpl  The name of the template file to parse; automatically searches through the template paths.
	 *
	 * @return  mixed  A string if successful, otherwise an Error object.
	 *
	 * @since   1.6
	 */
	public function display($tpl = null)
	{
		$app  = Factory::getApplication();
		$user = Factory::getUser();

		// Get view related request variables.
		$print = $app->input->getBool('print');

		// Get model data.
		$state = $this->get('State');
		$item  = $this->get('Item');

		// Check for errors.
		// @TODO: Maybe this could go into ComponentHelper::raiseErrors($this->get('Errors'))
		if (count($errors = $this->get('Errors')))
		{
			throw new GenericDataException(implode("\n", $errors), 500);
		}

		// Add router helpers.
		$item->slug = $item->alias ? ($item->id . ':' . $item->alias) : $item->id;
		$item->catslug = $item->category_alias ? ($item->catid . ':' . $item->category_alias) : $item->catid;
		$item->parent_slug = $item->category_alias ? ($item->parent_id . ':' . $item->parent_alias) : $item->parent_id;

		// Merge banhang params. If this is single-banhang view, menu params override banhang params
		// Otherwise, banhang params override menu item params
		$params = $state->get('params');
		$banhang_params = clone $item->params;
		$active = $app->getMenu()->getActive();
		$temp = clone $params;

		// Check to see which parameters should take priority
		if ($active)
		{
			$currentLink = $active->link;

			// If the current view is the active item and a banhang view for this feed, then the menu item params take priority
			if (strpos($currentLink, 'view=banhang') && strpos($currentLink, '&id=' . (string) $item->id))
			{
				// $item->params are the banhang params, $temp are the menu item params
				// Merge so that the menu item params take priority
				$banhang_params->merge($temp);
				$item->params = $banhang_params;

				// Load layout from active query (in case it is an alternative menu item)
				if (isset($active->query['layout']))
				{
					$this->setLayout($active->query['layout']);
				}
			}
			else
			{
				// Current view is not a single banhang, so the banhang params take priority here
				// Merge the menu item params with the banhang params so that the banhang params take priority
				$temp->merge($banhang_params);
				$item->params = $temp;

				// Check for alternative layouts (since we are not in a single-banhang menu item)
				if ($layout = $item->params->get('banhang_layout'))
				{
					$this->setLayout($layout);
				}
			}
		}
		else
		{
			// Merge so that banhang params take priority
			$temp->merge($banhang_params);
			$item->params = $temp;

			// Check for alternative layouts (since we are not in a single-banhang menu item)
			if ($layout = $item->params->get('banhang_layout'))
			{
				$this->setLayout($layout);
			}
		}

		// Check the access to the banhang
		$levels = $user->getAuthorisedViewLevels();

		if (!in_array($item->access, $levels) || (in_array($item->access, $levels) && (!in_array($item->category_access, $levels))))
		{
			$app->enqueueMessage(Text::_('JERROR_ALERTNOAUTHOR'), 'error');
			$app->setHeader('status', 403, true);

			return;
		}

		// Get the current menu item
		$params = $app->getParams();

		$params->merge($item->params);

		try
		{
			$feed = new FeedFactory;
			$this->rssDoc = $feed->getFeed($item->link);
		}
		catch (\InvalidArgumentException $e)
		{
			$msg = Text::_('COM_BANHANGS_ERRORS_FEED_NOT_RETRIEVED');
		}
		catch (\RuntimeException $e)
		{
			$msg = Text::_('COM_BANHANGS_ERRORS_FEED_NOT_RETRIEVED');
		}

		if (empty($this->rssDoc))
		{
			$msg = Text::_('COM_BANHANGS_ERRORS_FEED_NOT_RETRIEVED');
		}

		$feed_display_order = $params->get('feed_display_order', 'des');

		if ($feed_display_order === 'asc')
		{
			$this->rssDoc->reverseItems();
		}

		// Escape strings for HTML output
		$this->pageclass_sfx = htmlspecialchars($params->get('pageclass_sfx'));

		$this->params = $params;
		$this->state  = $state;
		$this->item   = $item;
		$this->user   = $user;

		if (!empty($msg))
		{
			$this->msg = $msg;
		}

		$this->print = $print;

		$item->tags = new TagsHelper;
		$item->tags->getItemTags('com_banhangs.banhang', $item->id);

		// Increment the hit counter of the banhang.
		$model = $this->getModel();
		$model->hit();

		$this->_prepareDocument();

		return parent::display($tpl);
	}

	/**
	 * Prepares the document
	 *
	 * @return  void
	 *
	 * @since   1.6
	 */
	protected function _prepareDocument()
	{
		$app     = Factory::getApplication();
		$pathway = $app->getPathway();

		// Because the application sets a default page title,
		// we need to get it from the menu item itself
		$menu = $app->getMenu()->getActive();

		if ($menu)
		{
			$this->params->def('page_heading', $this->params->get('page_title', $menu->title));
		}
		else
		{
			$this->params->def('page_heading', Text::_('COM_BANHANGS_DEFAULT_PAGE_TITLE'));
		}

		$title = $this->params->get('page_title', '');

		$id = (int) @$menu->query['id'];

		// If the menu item does not concern this banhang
		if ($menu && (!isset($menu->query['option']) || $menu->query['option'] !== 'com_banhangs' || $menu->query['view'] !== 'banhang'
			|| $id != $this->item->id))
		{
			// If this is not a single banhang menu item, set the page title to the banhang title
			if ($this->item->name)
			{
				$title = $this->item->name;
			}

			$path = array(array('title' => $this->item->name, 'link' => ''));
			$category = Categories::getInstance('Banhangs')->get($this->item->catid);

			while ((!isset($menu->query['option']) || $menu->query['option'] !== 'com_banhangs' || $menu->query['view'] === 'banhang'
				|| $id != $category->id) && $category->id > 1)
			{
				$path[] = array('title' => $category->title, 'link' => RouteHelper::getCategoryRoute($category->id));
				$category = $category->getParent();
			}

			$path = array_reverse($path);

			foreach ($path as $item)
			{
				$pathway->addItem($item['title'], $item['link']);
			}
		}

		if (empty($title))
		{
			$title = $this->item->name;
		}

		$this->setDocumentTitle($title);

		if ($this->item->metadesc)
		{
			$this->document->setDescription($this->item->metadesc);
		}
		elseif ($this->params->get('menu-meta_description'))
		{
			$this->document->setDescription($this->params->get('menu-meta_description'));
		}

		if ($this->params->get('robots'))
		{
			$this->document->setMetaData('robots', $this->params->get('robots'));
		}

		if ($app->get('MetaAuthor') == '1')
		{
			$this->document->setMetaData('author', $this->item->author);
		}

		$mdata = $this->item->metadata->toArray();

		foreach ($mdata as $k => $v)
		{
			if ($v)
			{
				$this->document->setMetaData($k, $v);
			}
		}
	}
}
